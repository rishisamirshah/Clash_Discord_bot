import requests


headers = {
    'Accept' : 'application/json',
    'authorization' : 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6IjQwMDkzOGNiLWZjZDItNDRkMC05MThkLWJhZjFjNjFjN2Q1MSIsImlhdCI6MTY0Mjg3OTQxNSwic3ViIjoiZGV2ZWxvcGVyL2E4ZTcyYmU2LTA4ZDktNmQ1NS02NjgwLTY0MTEwZDZiNDJlOSIsInNjb3BlcyI6WyJjbGFzaCJdLCJsaW1pdHMiOlt7InRpZXIiOiJkZXZlbG9wZXIvc2lsdmVyIiwidHlwZSI6InRocm90dGxpbmcifSx7ImNpZHJzIjpbIjE1My4zMy4zNC4xNTgiXSwidHlwZSI6ImNsaWVudCJ9XX0.fIxbunpWssXCjXjZAGoOP_WM_RhY_YSdEAVO-UC49m8vQSXB0M33G-mhLRi5YhhJxW0gEvWezvw3nE6ielHOXw'
}
def get_userName():
    response = requests.get('https://api.clashofclans.com/v1/players/%239YQR2LPV', headers=headers)
    user_json = response.json()
    print(user_json)

def get_userTrophies():
    response = requests.get('https://api.clashofclans.com/v1/players/%239YQR2LPV', headers=headers)
    user_json = response.json()
    print(user_json['trophies'])

    

get_userName()
get_userTrophies()